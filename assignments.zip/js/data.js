[
    {
        "title" : "sheet 4, 5",
        "subject" : "Control",
        "description" : "Routh Criterion and signal flow graph",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 20,
            "hours" : 9,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Programming Assignment",
        "subject" : "Control",
        "description" : "Routh Criterion",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 26,
            "hours" : 9,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Programming Assignment",
        "subject" : "Control",
        "description" : "Signal Flow Graph",
        "date" : {
            "year" : 2016,
            "month" : 3,
            "day" : 23,
            "hours" : 9,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Lab 1",
        "subject" : "Data Structure",
        "description" : "binary heaps and sorting techniques",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 27,
            "hours" : 23,
            "minutes" : 59
        }
    },
    
    {
        "title" : "Sheet 1",
        "subject" : "Data Structure",
        "description" : "Asymtotic Notations and Recurrence relations",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 3,
            "hours" : 10,
            "minutes" : 10
        }
    },
    
    {
        "title" : "Sheet 2",
        "subject" : "Data Structure",
        "description" : "binary heaps and binary search trees",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 22,
            "hours" : 10,
            "minutes" : 10
        }
    },
    
    {
        "title" : "Sheet 3",
        "subject" : "Numerical Analysis",
        "description" : "",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 24,
            "hours" : 12,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Sheet 1",
        "subject" : "Numerical Analysis",
        "description" : "",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 3,
            "hours" : 12,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Sheet 2",
        "subject" : "Numerical Analysis",
        "description" : "",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 18,
            "hours" : 12,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Lab 2",
        "subject" : "Digital",
        "description" : "cache simulator",
        "date" : {
            "year" : 2016,
            "month" : 3,
            "day" : 10,
            "hours" : 14,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Lab 1",
        "subject" : "Digital",
        "description" : "graph of finite memory machine",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 3,
            "hours" : 14,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Sheet 1",
        "subject" : "Digital",
        "description" : "graph of finite memory machine",
        "date" : {
            "year" : 2016,
            "month" : 1,
            "day" : 27,
            "hours" : 9,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Lab 2",
        "subject" : "System Programming",
        "description" : "send report to: csed.system.programming@gmail.com",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 24,
            "hours" : 8,
            "minutes" : 0
        }
    },
    
    {
        "title" : "Lab 1",
        "subject" : "System Programming",
        "description" : "send report to: csed.system.programming@gmail.com",
        "date" : {
            "year" : 2016,
            "month" : 2,
            "day" : 16,
            "hours" : 8,
            "minutes" : 0
        }
    }
]
